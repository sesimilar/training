document.write('<script language="JavaScript" type="text/javascript" src="jsunit/app/jsUnitCore.js"></script>');
document.write("<h1>" + document.title + "</h1>");
document.write("<a href='jsunit/testRunner.html?testPage=" + document.location + "&autoRun=true'>Run this test</a>");

